module.exports = {
    url: 'mongodb://localhost:27017/digidplome', // URL de connexion à la base de données
    options: {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }
  };




