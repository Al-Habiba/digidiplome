
// const achievement=require('../controllers/achievement.crtl')
// route.post('/achievement', function(req, res){achievement.createAchievement })
// route.get('/achievement', function(req, res){achievement.getAchievements})
// route.get('/achievement/:id',function(req, res){ achievement.getAchievementById})
// route.put('/achievement/:id',function(req, res){ achievement.updateAchievement})
// route.post('/achievement/:id', function(req, res){achievement.deleteAchievement})




